staffranks.register_rank("admin",
                        "Admin",
                        "#ff0f0f")

staffranks.register_rank("modo",
                        "Moderator",
                        "#0d3785")

staffranks.register_rank("guardian",
                        "Guardian",
                        "#3cbebc")

staffranks.register_rank("build",
                        "Builder",
                        "#a50e8e")

staffranks.register_rank("helper",
                        "Helper",
                        "#e2cd11")

staffranks.register_rank("youtuber",
                        "YouTuber",
                        "#7e1f1f")

staffranks.register_rank("miner",
                        "Miner",
                        "#1df16b")

staffranks.register_rank("reporter",
                        "Reporter",
                        "#402283")

staffranks.register_rank("pro-pvp",
                        "PvP_Pro",
                        "#b35300")

staffranks.register_rank("retired",
                        "Experienced",
                        "#7558af")

staffranks.register_rank("rebel",
                        "Rebel",
                        "#ffffff")

staffranks.register_rank("guide",
                        "Guide",
                        "#a1ff87")

staffranks.register_rank("pro",
                        "Pro",
                        "#3d3d3d")

staffranks.register_rank("hero",
                        "Hero",
                        "#ffd045")

staffranks.register_rank("spanish",
                        "SpTeacher",
                        "#e68600")

staffranks.register_rank("cop",
                        "Police",
                        "#0c88ab")

staffranks.register_rank("fly",
                        "Air",
                        "#bef5fa")

staffranks.register_rank("super",
                        "Supreme",
                        "#630b1b")

staffranks.register_rank("dev",
                        "Developer",
                        "#5cfffa")

staffranks.register_rank("norank",
                        "-",
                        "#ffffff")

staffranks.register_rank("wolf",
                        "Wolf",
                        "#959bad")
